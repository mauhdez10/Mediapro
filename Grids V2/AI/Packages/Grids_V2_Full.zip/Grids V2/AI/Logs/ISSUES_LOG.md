# Issues Log

## OPEN-V2-001 — Windows Excel runtime regression testing

Static validation is complete, but V2 must be run on disposable copies of each supported grid type in Windows desktop Excel before replacing production.

## RESOLVED-V2-002 — Calculation property HRESULT 0x800A03EC

The V2 runtime does not set `Excel.Application.Calculation`. Formatting does not require that state change.

## OPEN-V2-003 — SportyNet golden parity

SportyNet Week 31 and the formatted reference are different weeks. Operator comparison remains required for final parity approval.

## RESOLVED-V2-004 — Broad SportyNet fallback scanning

The fallback now checks only row 2 of the first worksheet after all existing and known SportyNet filename routes fail. Full SportyNet scanning occurs only after that lightweight signature succeeds.
