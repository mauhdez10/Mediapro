# Changelog

## V2 development

- Created an isolated Grids V2 copy; production Grids remains unchanged.
- Added strict routing priority and SportyNet support.
- Added per-grid tab selection with All/First/Last behavior.
- Added bilingual English/Spanish console messages.
- Added a Settings UI that embeds configuration into the runtime script.
- Moved printer state into Settings with a no-Settings local fallback.
- Removed all dependency on setting `Excel.Application.Calculation`, addressing HRESULT `0x800A03EC`.
- Added Full, Manager, and Operator distribution builders.
- Tightened the unmatched-file SportyNet fallback to a first-worksheet row-2 header check. Plain names such as `Week 32.xlsx` use this soft check instead of direct filename classification.
- Consolidated Windows runtime validation into one smoke-test entry point to keep the AI test folder simple.
