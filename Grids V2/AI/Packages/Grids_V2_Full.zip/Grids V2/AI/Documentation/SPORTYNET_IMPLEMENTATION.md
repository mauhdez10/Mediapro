# SportyNet Implementation

SportyNet is formatted in place on every selected matching worksheet. The strict source signature is `A2=GMT`, `B2=BRT/BRA`, seven dates in `C2:I2`, duplicate `BRT/BRA` and `GMT` in `J2:K2`, 96 quarter-hour rows, and the four-item legend.

The formatter normalizes source GMT/BRT values, including deterministic `6.45 -> 06:45`, validates the 15-minute sequences and GMT/BRT offset, inserts CDMX, removes duplicate right-side time columns, preserves program merges/colors, applies the accepted text transformation and formatting, and saves the same workbook.

Already-formatted worksheets with `C2=CDMX` are skipped.


## Routing guard

Existing grid filename routes always win. Known SportyNet filename families include `SNETL - Week 31` and versioned names such as `WEEK 31 V.4` or `WEEK 31 V.4 1`. A plain unmatched name such as `Week 32.xlsx` is not directly classified by name; it receives the lightweight first-worksheet row-2 signature check. Full tab scanning starts only after a known name or that soft check routes the workbook to SportyNet.
