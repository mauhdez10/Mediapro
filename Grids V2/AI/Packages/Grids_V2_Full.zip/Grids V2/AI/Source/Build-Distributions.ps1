param([string]$Root = (Split-Path (Split-Path $PSScriptRoot -Parent) -Parent))
$ErrorActionPreference='Stop'
$packages=Join-Path $Root 'AI\Packages'; [void](New-Item -ItemType Directory -Path $packages -Force)
Add-Type -AssemblyName System.IO.Compression.FileSystem
function New-Package([string]$Name,[bool]$IncludeSettings,[bool]$IncludeAI) {
    $stage=Join-Path $env:TEMP ("GridsV2_"+[guid]::NewGuid().ToString('N')); [void](New-Item -ItemType Directory -Path $stage)
    try {
        Copy-Item (Join-Path $Root '1.Run Grid Script.bat') $stage
        Copy-Item (Join-Path $Root 'FormatGrids.ps1') $stage
        if ($IncludeSettings) { Copy-Item (Join-Path $Root 'Settings') (Join-Path $stage 'Settings') -Recurse }
        if ($IncludeAI) {
            Copy-Item (Join-Path $Root 'AI') (Join-Path $stage 'AI') -Recurse
            Remove-Item (Join-Path $stage 'AI\Packages\*') -Force -ErrorAction SilentlyContinue
            Remove-Item (Join-Path $stage 'AI\Trash\*') -Force -Recurse -ErrorAction SilentlyContinue
        }
        $zip=Join-Path $packages $Name
        if (Test-Path $zip) { Remove-Item $zip -Force }
        [IO.Compression.ZipFile]::CreateFromDirectory($stage,$zip,[IO.Compression.CompressionLevel]::Optimal,$false)
        Write-Host "Created $zip"
    } finally { Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue }
}
New-Package 'Grids_V2_Full.zip' $true $true
New-Package 'Grids_V2_Manager.zip' $true $false
New-Package 'Grids_V2_Operator.zip' $false $false
